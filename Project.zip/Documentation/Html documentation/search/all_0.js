var searchData=
[
  ['addposition_0',['addPosition',['../a00021.html#aab3ff91a5e0e4a317d12d649c84bfb9e',1,'Vertice']]],
  ['aprox_1',['aprox',['../a00008.html#a5a0a771ec7cff35a7ba35ed38a6eefe2',1,'Graphics3D.cpp']]]
];
