var searchData=
[
  ['computer_20programming_20_28110_29_56',['Computer programming (110)',['../index.html',1,'']]]
];
