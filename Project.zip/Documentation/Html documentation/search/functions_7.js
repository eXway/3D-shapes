var searchData=
[
  ['reposition_50',['reposition',['../a00029.html#ac24a00e8419e00649be7e6fd2c88430e',1,'Obj_3D']]],
  ['reposition_51',['rePosition',['../a00021.html#a49c5febfddde1d352eec0ced5fe91892',1,'Vertice']]],
  ['rotate_52',['rotate',['../a00021.html#adf0ae513c9b372a57b997e21a1cdb50d',1,'Vertice']]],
  ['rotatefigure_53',['rotateFigure',['../a00029.html#ab4ebbc7c3d16abbeb20bb28f3c40db48',1,'Obj_3D']]]
];
