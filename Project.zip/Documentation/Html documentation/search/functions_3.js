var searchData=
[
  ['get_39',['get',['../a00021.html#a1fcf73dafe1505601ce5a490366bab72',1,'Vertice']]]
];
