var searchData=
[
  ['example_20program_3a_57',['Example program:',['../a00046.html',1,'']]]
];
