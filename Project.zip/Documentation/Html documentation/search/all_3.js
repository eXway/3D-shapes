var searchData=
[
  ['get_8',['get',['../a00021.html#a1fcf73dafe1505601ce5a490366bab72',1,'Vertice']]],
  ['graphics3d_2eh_9',['Graphics3D.h',['../a00008.html',1,'']]]
];
