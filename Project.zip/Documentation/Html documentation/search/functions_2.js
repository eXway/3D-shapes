var searchData=
[
  ['edge_38',['Edge',['../a00025.html#ad6b85b9f955b88fcdc98b0c04d572d1d',1,'Edge::Edge(Vertice &amp;iv1, Vertice &amp;iv2)'],['../a00025.html#a3106b11d60125009dbf7a738ce540fdf',1,'Edge::Edge()']]]
];
