var searchData=
[
  ['vertice_55',['Vertice',['../a00021.html#a9dd7cf987cddf248b9d4e3d31bf8822b',1,'Vertice::Vertice()'],['../a00021.html#a4df9b51f5412e45199bc75652dfe4247',1,'Vertice::Vertice(double ix, double iy, double iz)']]]
];
